In fiecare director sunt cerintele.
Pentru scris shellcode poti folosi ollydbg sau x32dbg cu plugin-ul Multiline Ultimate Assembler; sunt si alte tools online.



Tools:
* Far manager		- https://www.farmanager.com/
* HxD Disk Editor 	- https://mh-nexus.de/en/hxd/
* vbindiff 		- https://www.cjmweb.net/vbindiff/